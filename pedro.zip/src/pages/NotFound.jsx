import React from 'react';

function Notfound() {

return <h2>Contact Page</h2>; }

export default Notfound;